# Instances in an AS Group<a name="EN-US_TOPIC_0043063046"></a>

-   **[Querying Instances in an AS Group](querying-instances-in-an-as-group.md)**  

-   **[Removing a Specified Instance from an AS Group](removing-a-specified-instance-from-an-as-group.md)**  

-   **[Performing Operations on Instances in Batches](performing-operations-on-instances-in-batches.md)**  


