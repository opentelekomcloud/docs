# AS Policy Execution Log<a name="EN-US_TOPIC_0120434957"></a>

<a name="table199783292520"></a>
<table><thead align="left"><tr id="row397842910511"><th class="cellrowborder" valign="top" width="23%" id="mcps1.1.6.1.1"><p id="p15782041099"><a name="p15782041099"></a><a name="p15782041099"></a><strong id="b458315351611"><a name="b458315351611"></a><a name="b458315351611"></a>Permission</strong></p>
</th>
<th class="cellrowborder" valign="top" width="20%" id="mcps1.1.6.1.2"><p id="p116571155977"><a name="p116571155977"></a><a name="p116571155977"></a><strong id="b114123101714"><a name="b114123101714"></a><a name="b114123101714"></a>APIs</strong></p>
</th>
<th class="cellrowborder" valign="top" width="17%" id="mcps1.1.6.1.3"><p id="p17522185717013"><a name="p17522185717013"></a><a name="p17522185717013"></a><strong id="b1883105710165"><a name="b1883105710165"></a><a name="b1883105710165"></a>Actions</strong></p>
</th>
<th class="cellrowborder" valign="top" width="18%" id="mcps1.1.6.1.4"><p id="p1820911553480"><a name="p1820911553480"></a><a name="p1820911553480"></a>IAM Project</p>
<p id="p14209185534811"><a name="p14209185534811"></a><a name="p14209185534811"></a> </p>
</th>
<th class="cellrowborder" valign="top" width="22%" id="mcps1.1.6.1.5"><p id="p920917552480"><a name="p920917552480"></a><a name="p920917552480"></a>Enterprise Project</p>
<p id="p1320935511488"><a name="p1320935511488"></a><a name="p1320935511488"></a> </p>
</th>
</tr>
</thead>
<tbody><tr id="row14978112917515"><td class="cellrowborder" valign="top" width="23%" headers="mcps1.1.6.1.1 "><p id="p1953272912176"><a name="p1953272912176"></a><a name="p1953272912176"></a>Querying AS policy execution logs</p>
</td>
<td class="cellrowborder" valign="top" width="20%" headers="mcps1.1.6.1.2 "><p id="p1297815291656"><a name="p1297815291656"></a><a name="p1297815291656"></a>GET /autoscaling-api/v1/{project_id}/scaling_policy_execute_log/{scaling_policy_id}</p>
</td>
<td class="cellrowborder" valign="top" width="17%" headers="mcps1.1.6.1.3 "><p id="p179781429659"><a name="p179781429659"></a><a name="p179781429659"></a>as:policyExecuteLogs:list</p>
</td>
<td class="cellrowborder" valign="top" width="18%" headers="mcps1.1.6.1.4 "><p id="p936118804910"><a name="p936118804910"></a><a name="p936118804910"></a>√</p>
</td>
<td class="cellrowborder" valign="top" width="22%" headers="mcps1.1.6.1.5 "><p id="p728811916449"><a name="p728811916449"></a><a name="p728811916449"></a>√</p>
</td>
</tr>
</tbody>
</table>

