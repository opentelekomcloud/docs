# AS Configurations<a name="EN-US_TOPIC_0043063039"></a>

-   **[Creating an AS Configuration](creating-an-as-configuration.md)**  

-   **[Querying AS Configurations](querying-as-configurations.md)**  

-   **[Querying AS Configuration Details](querying-as-configuration-details.md)**  

-   **[Deleting an AS Configuration](deleting-an-as-configuration.md)**  

-   **[Batch Deleting AS Configurations](batch-deleting-as-configurations.md)**  


