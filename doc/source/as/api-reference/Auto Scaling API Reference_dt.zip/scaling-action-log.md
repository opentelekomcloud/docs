# Scaling Action Log<a name="EN-US_TOPIC_0120434958"></a>

<a name="table6297203615613"></a>
<table><thead align="left"><tr id="row12297636266"><th class="cellrowborder" valign="top" width="23.232323232323232%" id="mcps1.1.6.1.1"><p id="p61031358882"><a name="p61031358882"></a><a name="p61031358882"></a><strong id="b132646871713"><a name="b132646871713"></a><a name="b132646871713"></a>Permission</strong></p>
</th>
<th class="cellrowborder" valign="top" width="20.2020202020202%" id="mcps1.1.6.1.2"><p id="p7355162712816"><a name="p7355162712816"></a><a name="p7355162712816"></a><strong id="b11617015171719"><a name="b11617015171719"></a><a name="b11617015171719"></a>APIs</strong></p>
</th>
<th class="cellrowborder" valign="top" width="17.17171717171717%" id="mcps1.1.6.1.3"><p id="p17522185717013"><a name="p17522185717013"></a><a name="p17522185717013"></a><strong id="b59821810111710"><a name="b59821810111710"></a><a name="b59821810111710"></a>Actions</strong></p>
</th>
<th class="cellrowborder" valign="top" width="17.17171717171717%" id="mcps1.1.6.1.4"><p id="p1820911553480"><a name="p1820911553480"></a><a name="p1820911553480"></a>IAM Project</p>
<p id="p14209185534811"><a name="p14209185534811"></a><a name="p14209185534811"></a> </p>
</th>
<th class="cellrowborder" valign="top" width="22.22222222222222%" id="mcps1.1.6.1.5"><p id="p920917552480"><a name="p920917552480"></a><a name="p920917552480"></a>Enterprise Project</p>
<p id="p1320935511488"><a name="p1320935511488"></a><a name="p1320935511488"></a> </p>
</th>
</tr>
</thead>
<tbody><tr id="row829720361060"><td class="cellrowborder" valign="top" width="23.232323232323232%" headers="mcps1.1.6.1.1 "><p id="p18451949152018"><a name="p18451949152018"></a><a name="p18451949152018"></a>Querying scaling action logs</p>
</td>
<td class="cellrowborder" valign="top" width="20.2020202020202%" headers="mcps1.1.6.1.2 "><p id="p1729711367610"><a name="p1729711367610"></a><a name="p1729711367610"></a>GET /autoscaling-api/v1/{project_id}/scaling_activity_log/{scaling_group_id}</p>
</td>
<td class="cellrowborder" valign="top" width="17.17171717171717%" headers="mcps1.1.6.1.3 "><p id="p329713361468"><a name="p329713361468"></a><a name="p329713361468"></a>as:activityLogs:list</p>
</td>
<td class="cellrowborder" valign="top" width="17.17171717171717%" headers="mcps1.1.6.1.4 "><p id="p936118804910"><a name="p936118804910"></a><a name="p936118804910"></a>√</p>
</td>
<td class="cellrowborder" valign="top" width="22.22222222222222%" headers="mcps1.1.6.1.5 "><p id="p728811916449"><a name="p728811916449"></a><a name="p728811916449"></a>√</p>
</td>
</tr>
<tr id="row795812513117"><td class="cellrowborder" valign="top" width="23.232323232323232%" headers="mcps1.1.6.1.1 "><p id="p1395995810"><a name="p1395995810"></a><a name="p1395995810"></a>Querying scaling action logs (V2)</p>
</td>
<td class="cellrowborder" valign="top" width="20.2020202020202%" headers="mcps1.1.6.1.2 "><p id="p1832531318110"><a name="p1832531318110"></a><a name="p1832531318110"></a>GET /autoscaling-api/v2/{project_id}/scaling_activity_log/{scaling_group_id}</p>
</td>
<td class="cellrowborder" valign="top" width="17.17171717171717%" headers="mcps1.1.6.1.3 "><p id="p2959195119"><a name="p2959195119"></a><a name="p2959195119"></a>as:activityLogs:list</p>
</td>
<td class="cellrowborder" valign="top" width="17.17171717171717%" headers="mcps1.1.6.1.4 "><p id="p1381159135710"><a name="p1381159135710"></a><a name="p1381159135710"></a>√</p>
</td>
<td class="cellrowborder" valign="top" width="22.22222222222222%" headers="mcps1.1.6.1.5 "><p id="p0381159135712"><a name="p0381159135712"></a><a name="p0381159135712"></a>√</p>
</td>
</tr>
</tbody>
</table>

