# Tag Management<a name="EN-US_TOPIC_0120460581"></a>

<a name="table5773912426"></a>
<table><thead align="left"><tr id="row178123994218"><th class="cellrowborder" valign="top" width="23%" id="mcps1.1.6.1.1"><p id="p156502141495"><a name="p156502141495"></a><a name="p156502141495"></a><strong id="b472302141816"><a name="b472302141816"></a><a name="b472302141816"></a>Permission</strong></p>
</th>
<th class="cellrowborder" valign="top" width="21%" id="mcps1.1.6.1.2"><p id="p18434251433"><a name="p18434251433"></a><a name="p18434251433"></a><strong id="b1044111211181"><a name="b1044111211181"></a><a name="b1044111211181"></a>APIs</strong></p>
</th>
<th class="cellrowborder" valign="top" width="17%" id="mcps1.1.6.1.3"><p id="p17522185717013"><a name="p17522185717013"></a><a name="p17522185717013"></a><strong id="b798115551813"><a name="b798115551813"></a><a name="b798115551813"></a>Actions</strong></p>
</th>
<th class="cellrowborder" valign="top" width="17%" id="mcps1.1.6.1.4"><p id="p1820911553480"><a name="p1820911553480"></a><a name="p1820911553480"></a>IAM Project</p>
<p id="p14209185534811"><a name="p14209185534811"></a><a name="p14209185534811"></a> </p>
</th>
<th class="cellrowborder" valign="top" width="22%" id="mcps1.1.6.1.5"><p id="p920917552480"><a name="p920917552480"></a><a name="p920917552480"></a>Enterprise Project</p>
<p id="p1320935511488"><a name="p1320935511488"></a><a name="p1320935511488"></a> </p>
</th>
</tr>
</thead>
<tbody><tr id="row288398427"><td class="cellrowborder" valign="top" width="23%" headers="mcps1.1.6.1.1 "><p id="p11840203182819"><a name="p11840203182819"></a><a name="p11840203182819"></a>Querying tags</p>
</td>
<td class="cellrowborder" valign="top" width="21%" headers="mcps1.1.6.1.2 "><p id="p943225335"><a name="p943225335"></a><a name="p943225335"></a>GET /autoscaling-api/v1/{project_id}/{resource_type}/tags</p>
</td>
<td class="cellrowborder" valign="top" width="17%" headers="mcps1.1.6.1.3 "><p id="p48133974216"><a name="p48133974216"></a><a name="p48133974216"></a>as:tags:list</p>
</td>
<td class="cellrowborder" valign="top" width="17%" headers="mcps1.1.6.1.4 "><p id="p936118804910"><a name="p936118804910"></a><a name="p936118804910"></a>√</p>
</td>
<td class="cellrowborder" valign="top" width="22%" headers="mcps1.1.6.1.5 "><p id="p12840434242"><a name="p12840434242"></a><a name="p12840434242"></a>×</p>
</td>
</tr>
<tr id="row28123911426"><td class="cellrowborder" valign="top" width="23%" headers="mcps1.1.6.1.1 "><p id="p484011317284"><a name="p484011317284"></a><a name="p484011317284"></a>Querying tags of a resource</p>
</td>
<td class="cellrowborder" valign="top" width="21%" headers="mcps1.1.6.1.2 "><p id="p1643125531"><a name="p1643125531"></a><a name="p1643125531"></a>GET /autoscaling-api/v1/{project_id}/{resource_type}/{resource_id}/tags</p>
</td>
<td class="cellrowborder" valign="top" width="17%" headers="mcps1.1.6.1.3 "><p id="p138039124214"><a name="p138039124214"></a><a name="p138039124214"></a>as:tags:get</p>
</td>
<td class="cellrowborder" valign="top" width="17%" headers="mcps1.1.6.1.4 "><p id="p1381159135710"><a name="p1381159135710"></a><a name="p1381159135710"></a>√</p>
</td>
<td class="cellrowborder" valign="top" width="22%" headers="mcps1.1.6.1.5 "><p id="p686319341743"><a name="p686319341743"></a><a name="p686319341743"></a>×</p>
</td>
</tr>
<tr id="row188163984215"><td class="cellrowborder" valign="top" width="23%" headers="mcps1.1.6.1.1 "><p id="p1584053115288"><a name="p1584053115288"></a><a name="p1584053115288"></a>Updating or deleting a tag</p>
</td>
<td class="cellrowborder" valign="top" width="21%" headers="mcps1.1.6.1.2 "><p id="p144322511316"><a name="p144322511316"></a><a name="p144322511316"></a>POST /autoscaling-api/v1/{project_id}/{resource_type}/{resource_id}/tags/action</p>
</td>
<td class="cellrowborder" valign="top" width="17%" headers="mcps1.1.6.1.3 "><p id="p118153920423"><a name="p118153920423"></a><a name="p118153920423"></a>as:tags:set</p>
</td>
<td class="cellrowborder" valign="top" width="17%" headers="mcps1.1.6.1.4 "><p id="p25255162009"><a name="p25255162009"></a><a name="p25255162009"></a>√</p>
</td>
<td class="cellrowborder" valign="top" width="22%" headers="mcps1.1.6.1.5 "><p id="p288510341840"><a name="p288510341840"></a><a name="p288510341840"></a>×</p>
</td>
</tr>
<tr id="row3157175131516"><td class="cellrowborder" valign="top" width="23%" headers="mcps1.1.6.1.1 "><p id="p1157135101510"><a name="p1157135101510"></a><a name="p1157135101510"></a>Querying resources</p>
</td>
<td class="cellrowborder" valign="top" width="21%" headers="mcps1.1.6.1.2 "><p id="p143192514310"><a name="p143192514310"></a><a name="p143192514310"></a>POST /autoscaling-api/v1/{project_id}/{resource_type}/resource_instances/action</p>
</td>
<td class="cellrowborder" valign="top" width="17%" headers="mcps1.1.6.1.3 "><p id="p815715161517"><a name="p815715161517"></a><a name="p815715161517"></a>as:tagResources:list</p>
</td>
<td class="cellrowborder" valign="top" width="17%" headers="mcps1.1.6.1.4 "><p id="p5965141615113"><a name="p5965141615113"></a><a name="p5965141615113"></a>√</p>
</td>
<td class="cellrowborder" valign="top" width="22%" headers="mcps1.1.6.1.5 "><p id="p78871934546"><a name="p78871934546"></a><a name="p78871934546"></a>×</p>
</td>
</tr>
</tbody>
</table>

