# Permissions Policies and Supported Actions<a name="EN-US_TOPIC_0120434952"></a>

-   **[AS Group](as-group.md)**  

-   **[AS Configuration](as-configuration.md)**  

-   **[Instance](instance.md)**  

-   **[AS Policy](as-policy.md)**  

-   **[AS Policy Execution Log](as-policy-execution-log.md)**  

-   **[Scaling Action Log](scaling-action-log.md)**  

-   **[Quota](quota.md)**  

-   **[Tag Management](tag-management-0.md)**  


