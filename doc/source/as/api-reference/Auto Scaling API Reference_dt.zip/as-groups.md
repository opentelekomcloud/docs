# AS Groups<a name="EN-US_TOPIC_0043063066"></a>

-   **[Creating an AS Group](creating-an-as-group.md)**  

-   **[Querying AS Groups](querying-as-groups.md)**  

-   **[Querying AS Group Details](querying-as-group-details.md)**  

-   **[Modifying an AS Group](modifying-an-as-group.md)**  

-   **[Deleting an AS Group](deleting-an-as-group.md)**  

-   **[Enabling or Disabling an AS Group](enabling-or-disabling-an-as-group.md)**  


