# Tag Management<a name="EN-US_TOPIC_0066763616"></a>

-   **[Querying Tags](querying-tags.md)**  

-   **[Querying Tags of a Resource](querying-tags-of-a-resource.md)**  

-   **[Creating or Deleting a Tag](creating-or-deleting-a-tag.md)**  

-   **[Querying Resources](querying-resources.md)**  


