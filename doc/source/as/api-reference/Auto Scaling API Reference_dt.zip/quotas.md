# Quotas<a name="EN-US_TOPIC_0043063061"></a>

-   **[Querying AS Quotas](querying-as-quotas.md)**  

-   **[Querying AS policy and instance quotas](querying-as-policy-and-instance-quotas.md)**  


