# Scaling Action Logs<a name="EN-US_TOPIC_0043063022"></a>

-   **[Querying Scaling Action Logs](querying-scaling-action-logs.md)**  

-   **[Querying Scaling Action Logs \(V2\)](querying-scaling-action-logs-(v2).md)**  


