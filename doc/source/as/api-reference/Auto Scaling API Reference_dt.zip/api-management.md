# API Management<a name="EN-US_TOPIC_0133153515"></a>

-   **[Querying API Versions](querying-api-versions.md)**  

-   **[Querying a Specified API Version](querying-a-specified-api-version.md)**  


