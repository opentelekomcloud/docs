# Change History<a name="EN-US_TOPIC_0043063038"></a>

<a name="table58706923141436"></a>
<table><thead align="left"><tr id="row19905868141436"><th class="cellrowborder" valign="top" width="20.119999999999997%" id="mcps1.1.3.1.1"><p id="p23907317142638"><a name="p23907317142638"></a><a name="p23907317142638"></a>Released On</p>
</th>
<th class="cellrowborder" valign="top" width="79.88%" id="mcps1.1.3.1.2"><p id="p3127811132119"><a name="p3127811132119"></a><a name="p3127811132119"></a>Description</p>
</th>
</tr>
</thead>
<tbody><tr id="row1471183020"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p18112187133010"><a name="p18112187133010"></a><a name="p18112187133010"></a>2019-10-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p111277183018"><a name="p111277183018"></a><a name="p111277183018"></a>Added the following content:</p>
<a name="ul19112167113020"></a><a name="ul19112167113020"></a><ul id="ul19112167113020"><li>Added the <strong id="b679120119594"><a name="b679120119594"></a><a name="b679120119594"></a>without_any_tag </strong>parameter.</li></ul>
</td>
</tr>
<tr id="row45317301351"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p19203253111"><a name="p19203253111"></a><a name="p19203253111"></a>2019-09-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p29203212318"><a name="p29203212318"></a><a name="p29203212318"></a>Added the following content:</p>
<a name="ul292011219313"></a><a name="ul292011219313"></a><ul id="ul292011219313"><li>Added the <strong id="b264224412266"><a name="b264224412266"></a><a name="b264224412266"></a>delete_volume</strong> parameter to <a href="creating-an-as-group.md">Creating an AS Group</a>, <a href="querying-as-groups.md">Querying AS Groups</a>, <a href="querying-as-group-details.md">Querying AS Group Details</a>, and <a href="modifying-an-as-group.md">Modifying an AS Group</a>.</li><li>Added error code AS.1090 to <a href="error-codes.md">Error Codes</a>.</li></ul>
</td>
</tr>
<tr id="row1028810685511"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p640512885320"><a name="p640512885320"></a><a name="p640512885320"></a>2019-05-31</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p20915153825516"><a name="p20915153825516"></a><a name="p20915153825516"></a>Added the following content:</p>
<a name="ul1092613711494"></a><a name="ul1092613711494"></a><ul id="ul1092613711494"><li>Added error code AS.2054 to <a href="error-codes.md">Error Codes</a>.</li></ul>
<p id="p640554675513"><a name="p640554675513"></a><a name="p640554675513"></a>Modified the following content:</p>
<a name="ul204387469553"></a><a name="ul204387469553"></a><ul id="ul204387469553"><li>Modified the <strong id="b276123044812"><a name="b276123044812"></a><a name="b276123044812"></a>available_zones</strong> description in <a href="modifying-an-as-group.md">Modifying an AS Group</a> because adding, changing, and deleting the AZ without disabling the AS group is supported.</li><li>Optimized <a href="permissions-policies-and-supported-actions.md">Permissions Policies and Supported Actions</a>.</li></ul>
</td>
</tr>
<tr id="row14908112711306"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p5442154511256"><a name="p5442154511256"></a><a name="p5442154511256"></a>2019-04-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p7459135663011"><a name="p7459135663011"></a><a name="p7459135663011"></a>Added the following content:</p>
<a name="ul16312818162919"></a><a name="ul16312818162919"></a><ul id="ul16312818162919"><li>Added the <strong id="b289645212916"><a name="b289645212916"></a><a name="b289645212916"></a>log_id</strong> and <strong id="b108981652172920"><a name="b108981652172920"></a><a name="b108981652172920"></a>status</strong> fields to <a href="querying-scaling-action-logs-(v2).md">Querying Scaling Action Logs (V2)</a>.</li><li>Added error codes AS.9012 and AS.9013 to <a href="error-codes.md">Error Codes</a>.</li><li>Adjusted the document structure and raised the category level of APIs and error codes.</li></ul>
</td>
</tr>
<tr id="row105261795218"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p613817114220"><a name="p613817114220"></a><a name="p613817114220"></a>2019-03-31</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p112812912553"><a name="p112812912553"></a><a name="p112812912553"></a>Added the following content:</p>
<a name="ul7383291559"></a><a name="ul7383291559"></a><ul id="ul7383291559"><li>Added the <strong id="b369205614517"><a name="b369205614517"></a><a name="b369205614517"></a>multi_flavor_priority_policy</strong>, <strong id="b197085615516"><a name="b197085615516"></a><a name="b197085615516"></a>multi_az_priority_policy</strong>, and <strong id="b157195610517"><a name="b157195610517"></a><a name="b157195610517"></a>instance_config</strong> parameters.</li><li>Added error codes AS.1085, AS.1086, AS.1087, AS.1088, AS.2053, and AS.7016 to <a href="error-codes.md">Error Codes</a>.</li></ul>
<p id="p17518335195513"><a name="p17518335195513"></a><a name="p17518335195513"></a>Modified the following content:</p>
<a name="ul3524103511551"></a><a name="ul3524103511551"></a><ul id="ul3524103511551"><li>Modified error codes AS.1017, AS.1018, AS.1032, AS.1036, AS.2038, and AS.2043 in <a href="error-codes.md">Error Codes</a>.</li></ul>
</td>
</tr>
<tr id="row1285172463515"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p776716325355"><a name="p776716325355"></a><a name="p776716325355"></a>2019-02-28</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p201826115369"><a name="p201826115369"></a><a name="p201826115369"></a>Added the following content:</p>
<a name="ul13203192712351"></a><a name="ul13203192712351"></a><ul id="ul13203192712351"><li>Added parameter <strong id="b18118104617811"><a name="b18118104617811"></a><a name="b18118104617811"></a>enterprise_project_id</strong> to <a href="as-groups.md">AS Groups</a>.</li><li>Added <a href="permissions-policies-and-supported-actions.md">Permissions Policies and Supported Actions</a> for fine-grained permissions.</li></ul>
<p id="p19365171193719"><a name="p19365171193719"></a><a name="p19365171193719"></a>Modified the following content:</p>
<a name="ul837131133717"></a><a name="ul837131133717"></a><ul id="ul837131133717"><li>Optimized the document, including the function description and parameter description of each interface, as well as the format of request and response examples.</li></ul>
</td>
</tr>
<tr id="row366712135114"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p1325082315120"><a name="p1325082315120"></a><a name="p1325082315120"></a>2018-11-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p20257123125111"><a name="p20257123125111"></a><a name="p20257123125111"></a>Added the following content:</p>
<a name="ul577965145214"></a><a name="ul577965145214"></a><ul id="ul577965145214"><li>Added parameter <strong id="b98151140973"><a name="b98151140973"></a><a name="b98151140973"></a>protect_from_scaling_down</strong> to <a href="querying-instances-in-an-as-group.md">Querying Instances in an AS Group</a>.</li><li>Added <a href="querying-scaling-action-logs-(v2).md">Querying Scaling Action Logs (V2)</a>.</li><li>Added error codes AS.2047 and AS.7066 to <a href="error-codes.md">Error Codes</a>.</li></ul>
<p id="p11835155205419"><a name="p11835155205419"></a><a name="p11835155205419"></a>Modified the following content:</p>
<p id="p43549145418"><a name="p43549145418"></a><a name="p43549145418"></a>Modified error codes AS.2015, AS.2035, and AS.2042 in <a href="error-codes.md">Error Codes</a>.</p>
</td>
</tr>
<tr id="row1396311191292"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p1841420449296"><a name="p1841420449296"></a><a name="p1841420449296"></a>2018-09-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p5616177193117"><a name="p5616177193117"></a><a name="p5616177193117"></a>Added the following content:</p>
<a name="ul1875316521786"></a><a name="ul1875316521786"></a><ul id="ul1875316521786"><li>Added <a href="querying-all-as-policies-(v2).md">Querying All AS Policies (V2)</a>.</li><li>Added error codes AS.1033, AS.1068, AS.1069, AS.1072, AS.1074, AS.1075, and AS.1076 to <a href="error-codes.md">Error Codes</a>.</li><li>Added <a href="api-management.md">API Management</a>, <a href="querying-api-versions.md">Querying API Versions</a>, and <a href="querying-a-specified-api-version.md">Querying a Specified API Version</a>.</li><li>Added <a href="api.md">API</a>.</li></ul>
</td>
</tr>
<tr id="row77878234120"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p11480725519"><a name="p11480725519"></a><a name="p11480725519"></a>2018-08-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p649262516113"><a name="p649262516113"></a><a name="p649262516113"></a>Modified the following content:</p>
<a name="ul184801599203"></a><a name="ul184801599203"></a><ul id="ul184801599203"><li>Added <a href="querying-resources.md">Querying Resources</a>.</li><li>Changed the default cooldown period to 300s.</li><li>Added error code AS.1067 to <a href="error-codes.md">Error Codes</a>.</li></ul>
</td>
</tr>
<tr id="row35939216306"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p3593621113014"><a name="p3593621113014"></a><a name="p3593621113014"></a>2018-08-14</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p115946211304"><a name="p115946211304"></a><a name="p115946211304"></a>Modified the following content:</p>
<p id="p1664914713312"><a name="p1664914713312"></a><a name="p1664914713312"></a>Accepted in OTC-3.2/Agile 09.2018.</p>
</td>
</tr>
<tr id="row17662163282919"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p146631323297"><a name="p146631323297"></a><a name="p146631323297"></a>2018-07-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p1766320321295"><a name="p1766320321295"></a><a name="p1766320321295"></a>Modified the following content:</p>
<a name="ul117135163712"></a><a name="ul117135163712"></a><ul id="ul117135163712"><li>Added the AS bandwidth feature.</li><li>Added error codes AS.3050, AS.7061, AS.7062, and AS.7063 to <a href="error-codes.md">Error Codes</a>.</li><li>Modified error code AS.7047 in <a href="error-codes.md">Error Codes</a>.</li></ul>
</td>
</tr>
<tr id="row9934626191113"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p1030173215115"><a name="p1030173215115"></a><a name="p1030173215115"></a>2018-05-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p99351826181119"><a name="p99351826181119"></a><a name="p99351826181119"></a>Modified the following content:</p>
<a name="ul15722316211"></a><a name="ul15722316211"></a><ul id="ul15722316211"><li>Added parameter <strong id="b1297617421612"><a name="b1297617421612"></a><a name="b1297617421612"></a>security_groups</strong> to <a href="as-configurations.md">AS Configurations</a>.</li></ul>
<a name="ul531162917129"></a><a name="ul531162917129"></a><ul id="ul531162917129"><li>Added <a href="performing-operations-on-as-policies-in-batches.md">Performing Operations on AS Policies in Batches</a>.</li><li>Added error codes AS.0026, AS.3045, AS.3046, AS.3047, AS.3048, and AS.3049 to <a href="error-codes.md">Error Codes</a>.</li><li>Modified error codes AS.3004, AS.3008, AS.3009, AS.3010, and AS.3033 in <a href="error-codes.md">Error Codes</a>.</li></ul>
</td>
</tr>
<tr id="row2056911215167"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p15691821131618"><a name="p15691821131618"></a><a name="p15691821131618"></a>2018-04-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p093812462417"><a name="p093812462417"></a><a name="p093812462417"></a>Modified the following content:</p>
<a name="ul129588016179"></a><a name="ul129588016179"></a><ul id="ul129588016179"><li>Added description of <strong id="b842352706122417"><a name="b842352706122417"></a><a name="b842352706122417"></a>health_periodic_audit_grace_period</strong> to <a href="creating-an-as-group.md">Creating an AS Group</a>.</li><li>Added description of <strong id="b1687496533"><a name="b1687496533"></a><a name="b1687496533"></a>health_periodic_audit_grace_period</strong> to <a href="modifying-an-as-group.md">Modifying an AS Group</a>.</li><li>Added the <strong id="b84235270612253"><a name="b84235270612253"></a><a name="b84235270612253"></a>scaling_policy_id</strong> field to <a href="querying-as-policies.md">Querying AS Policies</a>.</li><li>Added the <strong id="b842352706122533"><a name="b842352706122533"></a><a name="b842352706122533"></a>scaling_policy_id</strong> and <strong id="b842352706122536"><a name="b842352706122536"></a><a name="b842352706122536"></a>scaling_policy_name</strong> fields to <a href="querying-scaling-action-logs.md">Querying Scaling Action Logs</a>.</li><li>Added error code AS.2046 to <a href="error-codes.md">Error Codes</a>.</li></ul>
</td>
</tr>
<tr id="row9221134614335"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p5221846173312"><a name="p5221846173312"></a><a name="p5221846173312"></a>2018-03-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p1052312517338"><a name="p1052312517338"></a><a name="p1052312517338"></a>Modified the following content:</p>
<a name="ul352965113334"></a><a name="ul352965113334"></a><ul id="ul352965113334"><li>Modified the <strong id="b6699296094725"><a name="b6699296094725"></a><a name="b6699296094725"></a>Tag</strong> field description in <a href="querying-tags.md">Querying Tags</a>.</li><li>Modified the <strong id="b1286819915"><a name="b1286819915"></a><a name="b1286819915"></a>ResourceTag</strong> field description in <a href="querying-tags-of-a-resource.md">Querying Tags of a Resource</a>.</li><li>Modified the parameter description, <strong id="b842352706105939"><a name="b842352706105939"></a><a name="b842352706105939"></a>ResourceTag</strong> field description, and returned values in <a href="creating-or-deleting-a-tag.md">Creating or Deleting a Tag</a>.</li></ul>
</td>
</tr>
<tr id="row18958626143325"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p5150162143930"><a name="p5150162143930"></a><a name="p5150162143930"></a>2018-01-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p14509984143930"><a name="p14509984143930"></a><a name="p14509984143930"></a>Modified the following content:</p>
<a name="ul63481000143930"></a><a name="ul63481000143930"></a><ul id="ul63481000143930"><li>Added the field "Description" to <a href="performing-operations-on-instances-in-batches.md">Performing Operations on Instances in Batches</a>.</li><li>Added the parameters for forcibly deleting an AS group and their description to <a href="deleting-an-as-group.md">Deleting an AS Group</a>.</li><li>Added descriptions of the typical and enhanced ELBs to <a href="as-groups.md">AS Groups</a>.</li><li>Added the parameter <strong id="b842352706164142"><a name="b842352706164142"></a><a name="b842352706164142"></a>snapshot_id</strong> to <a href="as-configurations.md">AS Configurations</a>.</li><li>Optimized descriptions of error codes.</li></ul>
</td>
</tr>
<tr id="row17660758173345"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p21235269173345"><a name="p21235269173345"></a><a name="p21235269173345"></a>2017-11-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><div class="p" id="p42335217173345"><a name="p42335217173345"></a><a name="p42335217173345"></a>Modified the following content:<a name="ul62205848173449"></a><a name="ul62205848173449"></a><ul id="ul62205848173449"><li>Added the function of increasing or decreasing the number of instances in an AS group according to the percentage preset in the AS policy.</li><li>Added AS monitoring metrics.</li><li>Added the following error codes: AS.1019, AS.1020, AS.1053 to AS.1061, AS.2042, AS.2043, AS.3035, and AS.3036.</li><li>Added parameters <strong id="b262723984"><a name="b262723984"></a><a name="b262723984"></a>dedicated_storage_id</strong> and <strong id="b842352706164147"><a name="b842352706164147"></a><a name="b842352706164147"></a>data_disk_image_id</strong>.</li></ul>
</div>
</td>
</tr>
<tr id="row40335181162028"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p19614441162040"><a name="p19614441162040"></a><a name="p19614441162040"></a>2017-09-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><div class="p" id="p61402985162043"><a name="p61402985162043"></a><a name="p61402985162043"></a>Modified the following content:<a name="ul20426517174820"></a><a name="ul20426517174820"></a><ul id="ul20426517174820"><li>Added instance protection to <a href="querying-instances-in-an-as-group.md">Querying Instances in an AS Group</a> and <a href="performing-operations-on-instances-in-batches.md">Performing Operations on Instances in Batches</a>.</li><li>Added error codes 2010, 4032, 4033, 7044, 7045, 7047, 7048, 7049, and 7050.</li></ul>
</div>
</td>
</tr>
<tr id="row1364163172034"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p43388402172034"><a name="p43388402172034"></a><a name="p43388402172034"></a>2017-07-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p24799669172034"><a name="p24799669172034"></a><a name="p24799669172034"></a>Modified the following content:</p>
<p id="p66437062173748"><a name="p66437062173748"></a><a name="p66437062173748"></a>Added tag management.</p>
</td>
</tr>
<tr id="row4954032172244"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p65732298172244"><a name="p65732298172244"></a><a name="p65732298172244"></a>2017-03-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p22715941172244"><a name="p22715941172244"></a><a name="p22715941172244"></a>Modified the following content:</p>
<p id="p15908171020113"><a name="p15908171020113"></a><a name="p15908171020113"></a>Added error codes AS.2015, AS.2026, AS.2039, and AS.2040 to <a href="error-codes.md">Error Codes</a>.</p>
</td>
</tr>
<tr id="row9975661114254"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p10042120142753"><a name="p10042120142753"></a><a name="p10042120142753"></a>2016-12-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p2722188114254"><a name="p2722188114254"></a><a name="p2722188114254"></a>Modified the following content:</p>
<a name="ul61613953143218"></a><a name="ul61613953143218"></a><ul id="ul61613953143218"><li>Added parameter <strong id="b144862543715"><a name="b144862543715"></a><a name="b144862543715"></a>EIP</strong> to <a href="as-configurations.md">AS Configurations</a>.</li><li>Added parameter <strong id="b392811381484"><a name="b392811381484"></a><a name="b392811381484"></a>AZ</strong> to <a href="as-groups.md">AS Groups</a>.</li></ul>
</td>
</tr>
<tr id="row31300138143044"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p13378528142753"><a name="p13378528142753"></a><a name="p13378528142753"></a>2016-10-29</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p52283246143044"><a name="p52283246143044"></a><a name="p52283246143044"></a>Modified the following content:</p>
<p id="p186628143237"><a name="p186628143237"></a><a name="p186628143237"></a>Added the <strong id="b2020250745102022"><a name="b2020250745102022"></a><a name="b2020250745102022"></a>metadata</strong> field to <a href="creating-an-as-configuration.md">Creating an AS Configuration</a>.</p>
<p id="p1679655143237"><a name="p1679655143237"></a><a name="p1679655143237"></a>Added error codes AS.7011, AS.1049, AS.1050, and AS.1052 to <a href="error-codes.md">Error Codes</a>.</p>
</td>
</tr>
<tr id="row3367703095144"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p22161963142753"><a name="p22161963142753"></a><a name="p22161963142753"></a>2016-10-09</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p3465781495144"><a name="p3465781495144"></a><a name="p3465781495144"></a>Modified the following content:</p>
<p id="p6190309795233"><a name="p6190309795233"></a><a name="p6190309795233"></a>Modified the <strong id="b1925436128102122"><a name="b1925436128102122"></a><a name="b1925436128102122"></a>volume_type</strong> description in <a href="creating-an-as-configuration.md">Creating an AS Configuration</a>.</p>
</td>
</tr>
<tr id="row17714534115311"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p37033809142753"><a name="p37033809142753"></a><a name="p37033809142753"></a>2016-08-25</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p25213079115311"><a name="p25213079115311"></a><a name="p25213079115311"></a>Modified the following content:</p>
<a name="ul361043999388"></a><a name="ul361043999388"></a><ul id="ul361043999388"><li>Added regions and terminals for the CCE, RDS, and DNS services.</li></ul>
</td>
</tr>
<tr id="row20842155184129"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p19883947142753"><a name="p19883947142753"></a><a name="p19883947142753"></a>2016-08-09</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p53361667184129"><a name="p53361667184129"></a><a name="p53361667184129"></a>Modified the following content:</p>
<p id="p18434637184149"><a name="p18434637184149"></a><a name="p18434637184149"></a>Changed the maximum user data length to 32 KB in <a href="creating-an-as-configuration.md">Creating an AS Configuration</a>.</p>
</td>
</tr>
<tr id="row27603022172648"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p66991604142753"><a name="p66991604142753"></a><a name="p66991604142753"></a>2016-06-30</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p47100612172648"><a name="p47100612172648"></a><a name="p47100612172648"></a>Modified the following content:</p>
<a name="ul4813479617279"></a><a name="ul4813479617279"></a><ul id="ul4813479617279"><li>Modified parameter description in this document because an AS group has supported the binding of multiple ELB listeners.</li><li>Added error codes AS.2037 and AS.3034 to <a href="error-codes.md">Error Codes</a>.</li></ul>
</td>
</tr>
<tr id="row1877553016167"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p48735496142753"><a name="p48735496142753"></a><a name="p48735496142753"></a>2016-06-16</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p3476204616167"><a name="p3476204616167"></a><a name="p3476204616167"></a>Modified the following content:</p>
<a name="ul53397226161650"></a><a name="ul53397226161650"></a><ul id="ul53397226161650"><li>Modified descriptions about the <strong id="b842352706161820"><a name="b842352706161820"></a><a name="b842352706161820"></a>alarm_id</strong> and <strong id="b842352706161825"><a name="b842352706161825"></a><a name="b842352706161825"></a>scheduled_policy</strong> fields in <a href="creating-an-as-policy.md">Creating an AS Policy</a> and <a href="modifying-an-as-policy.md">Modifying an AS Policy</a>.</li><li>Modified content in <a href="quotas.md">Quotas</a>.</li></ul>
</td>
</tr>
<tr id="row14716095222239"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p27588235142753"><a name="p27588235142753"></a><a name="p27588235142753"></a>2016-06-02</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p65335992222239"><a name="p65335992222239"></a><a name="p65335992222239"></a>Modified the following content:</p>
<a name="ul27978520222457"></a><a name="ul27978520222457"></a><ul id="ul27978520222457"><li>Added the <strong id="b842352706114913"><a name="b842352706114913"></a><a name="b842352706114913"></a>instance_id</strong> field to <strong id="b842352706114927"><a name="b842352706114927"></a><a name="b842352706114927"></a>instance_config</strong> field description in <a href="creating-an-as-configuration.md">Creating an AS Configuration</a>.</li><li>Added the <strong id="b84235270611815"><a name="b84235270611815"></a><a name="b84235270611815"></a>delete_publicip</strong> field to <a href="querying-as-groups.md">Querying AS Groups</a> and <a href="querying-as-group-details.md">Querying AS Group Details</a>.</li></ul>
</td>
</tr>
<tr id="row5948370919272"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p44693455142753"><a name="p44693455142753"></a><a name="p44693455142753"></a>2016-05-05</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p6559133619272"><a name="p6559133619272"></a><a name="p6559133619272"></a>Modified the following content:</p>
<a name="ul28895498193350"></a><a name="ul28895498193350"></a><ul id="ul28895498193350"><li>Deleted <strong id="b842352706195745"><a name="b842352706195745"></a><a name="b842352706195745"></a>Parameter Type Description</strong> from <a href="appendix.md">Appendix</a>, and added parameter type information to each interface in the document body.</li></ul>
</td>
</tr>
<tr id="row57839479151014"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p33729918142753"><a name="p33729918142753"></a><a name="p33729918142753"></a>2016-04-14</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p12208999151014"><a name="p12208999151014"></a><a name="p12208999151014"></a>Modified the following content:</p>
<a name="ul1664648711045"></a><a name="ul1664648711045"></a><ul id="ul1664648711045"><li>Added the Identity and Access Management Service to the region and terminal nodes to <a href="querying-as-configuration-details.md">Querying AS Configuration Details</a>.</li></ul>
<a name="ul58568405183743"></a><a name="ul58568405183743"></a><ul id="ul58568405183743"><li>Modified response examples in <a href="querying-as-configuration-details.md">Querying AS Configuration Details</a>.</li></ul>
</td>
</tr>
<tr id="row21552840141436"><td class="cellrowborder" valign="top" width="20.119999999999997%" headers="mcps1.1.3.1.1 "><p id="p27266295142753"><a name="p27266295142753"></a><a name="p27266295142753"></a>2016-03-09</p>
</td>
<td class="cellrowborder" valign="top" width="79.88%" headers="mcps1.1.3.1.2 "><p id="p949640141436"><a name="p949640141436"></a><a name="p949640141436"></a>This issue is the first official release.</p>
</td>
</tr>
</tbody>
</table>

