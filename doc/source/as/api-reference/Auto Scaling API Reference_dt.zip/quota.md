# Quota<a name="EN-US_TOPIC_0120460558"></a>

<a name="table136899111019"></a>
<table><thead align="left"><tr id="row76812917100"><th class="cellrowborder" valign="top" width="22.999999999999996%" id="mcps1.1.6.1.1"><p id="p156502141495"><a name="p156502141495"></a><a name="p156502141495"></a><strong id="b3356122331714"><a name="b3356122331714"></a><a name="b3356122331714"></a>Permission</strong></p>
</th>
<th class="cellrowborder" valign="top" width="19.999999999999996%" id="mcps1.1.6.1.2"><p id="p738119531994"><a name="p738119531994"></a><a name="p738119531994"></a><strong id="b1247043513174"><a name="b1247043513174"></a><a name="b1247043513174"></a>APIs</strong></p>
</th>
<th class="cellrowborder" valign="top" width="17%" id="mcps1.1.6.1.3"><p id="p17522185717013"><a name="p17522185717013"></a><a name="p17522185717013"></a><strong id="b15154182881717"><a name="b15154182881717"></a><a name="b15154182881717"></a>Actions</strong></p>
</th>
<th class="cellrowborder" valign="top" width="17%" id="mcps1.1.6.1.4"><p id="p1820911553480"><a name="p1820911553480"></a><a name="p1820911553480"></a>IAM Project</p>
<p id="p14209185534811"><a name="p14209185534811"></a><a name="p14209185534811"></a> </p>
</th>
<th class="cellrowborder" valign="top" width="22.999999999999996%" id="mcps1.1.6.1.5"><p id="p920917552480"><a name="p920917552480"></a><a name="p920917552480"></a>Enterprise Project</p>
<p id="p1320935511488"><a name="p1320935511488"></a><a name="p1320935511488"></a> </p>
</th>
</tr>
</thead>
<tbody><tr id="row3682093107"><td class="cellrowborder" valign="top" width="22.999999999999996%" headers="mcps1.1.6.1.1 "><p id="p18112181072314"><a name="p18112181072314"></a><a name="p18112181072314"></a>Querying AS quotas</p>
</td>
<td class="cellrowborder" valign="top" width="19.999999999999996%" headers="mcps1.1.6.1.2 "><p id="p106810921012"><a name="p106810921012"></a><a name="p106810921012"></a>GET /autoscaling-api/v1/{project_id}/quotas</p>
</td>
<td class="cellrowborder" valign="top" width="17%" headers="mcps1.1.6.1.3 "><p id="p76899181011"><a name="p76899181011"></a><a name="p76899181011"></a>as:quotas:get</p>
</td>
<td class="cellrowborder" valign="top" width="17%" headers="mcps1.1.6.1.4 "><p id="p936118804910"><a name="p936118804910"></a><a name="p936118804910"></a>√</p>
</td>
<td class="cellrowborder" valign="top" width="22.999999999999996%" headers="mcps1.1.6.1.5 "><p id="p728811916449"><a name="p728811916449"></a><a name="p728811916449"></a>√</p>
</td>
</tr>
<tr id="row868149161012"><td class="cellrowborder" valign="top" width="22.999999999999996%" headers="mcps1.1.6.1.1 "><p id="p111221072312"><a name="p111221072312"></a><a name="p111221072312"></a>Querying AS policy and instance quotas</p>
</td>
<td class="cellrowborder" valign="top" width="19.999999999999996%" headers="mcps1.1.6.1.2 "><p id="p196810941019"><a name="p196810941019"></a><a name="p196810941019"></a>GET /autoscaling-api/v1/{project_id}/quotas/{scaling_group_id}</p>
</td>
<td class="cellrowborder" valign="top" width="17%" headers="mcps1.1.6.1.3 "><p id="p36817981011"><a name="p36817981011"></a><a name="p36817981011"></a>as:quotas:get</p>
</td>
<td class="cellrowborder" valign="top" width="17%" headers="mcps1.1.6.1.4 "><p id="p1381159135710"><a name="p1381159135710"></a><a name="p1381159135710"></a>√</p>
</td>
<td class="cellrowborder" valign="top" width="22.999999999999996%" headers="mcps1.1.6.1.5 "><p id="p0381159135712"><a name="p0381159135712"></a><a name="p0381159135712"></a>√</p>
</td>
</tr>
</tbody>
</table>

